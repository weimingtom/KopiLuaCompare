using Godot;
using KopiLua;
using System;
using System.Diagnostics;
using System.Drawing;

public partial class Hello : Node
{
	RichTextLabel richTextLabel;
	LineEdit lineEdit;
	static RichTextLabel g_richTextLabel;
	
	// Called when the node enters the scene tree for the first time.
	public override void _Ready()
	{
		Console.WriteLine("hello2");
		Debug.WriteLine("hello2");
		richTextLabel = this.GetNode<RichTextLabel>("RichTextLabel");
		//richTextLabel.Text = "Hello world!";
		lineEdit = this.GetNode<LineEdit>("LineEdit");
		//lineEdit.TextChanged += LineEdit_TextChanged;
		lineEdit.GuiInput += LineEdit_GuiInput;
		lineEdit.GrabFocus();

		g_richTextLabel = this.richTextLabel;
	}

	private void LineEdit_GuiInput(InputEvent @event)
	{
		////public override void _Input(InputEvent @event) {
		//throw new NotImplementedException();
		if (@event is InputEventKey keyEvent)
		{
			if (keyEvent.Keycode == Key.Enter && keyEvent.Pressed)
			{
				Debug.WriteLine("Key.Enter");
				if (this.richTextLabel != null)
				{
					if (false)
					{
						this.richTextLabel.AppendText(this.lineEdit.Text + "\n");
					}
					else
					{
						this.richTextLabel.AppendText("[color=gray] > " + this.lineEdit.Text + "[/color]\n");
					}

					String msg = Program.dolua_(this.lineEdit.Text);
					if (msg != null && msg.Length != 0)
					{
						if (false)
						{
							this.richTextLabel.AppendText(msg + "\n");
						}
						else
						{
							this.richTextLabel.AppendText("[color=red]" + msg + "[/color]\n");
						}	
					}
					this.richTextLabel.ScrollToLine(this.richTextLabel.GetLineCount() - 1);	
					this.lineEdit.Clear();
				}
			}
		}
	}

	public static void Log(String msg)
	{
		if (msg != null && msg.Length != 0)
		{
			if (g_richTextLabel != null)
			{
				g_richTextLabel.AppendText(msg + "\n");
			}
		}
		if (g_richTextLabel != null)
		{
			g_richTextLabel.ScrollToLine(g_richTextLabel.GetLineCount() - 1);
		}
	}

	private void LineEdit_TextChanged(string newText)
	{
		//throw new NotImplementedException();
		Debug.WriteLine("LineEdit_TextChanged: " + newText);
	}

	// Called every frame. 'delta' is the elapsed time since the previous frame.
	public override void _Process(double delta)
	{
		if (Input.IsKeyPressed(Key.Enter))
		{
			//Debug.WriteLine("Key.Enter");
		}
	}

	

}
