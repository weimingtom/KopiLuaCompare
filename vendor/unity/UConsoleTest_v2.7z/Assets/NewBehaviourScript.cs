﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class NewBehaviourScript : MonoBehaviour
{
    // Start is called before the first frame update
    void Start()
    {
        
    }

    void OnGUI()
    {
        GUI.Label(new Rect(25, 15, 100, 30), "Label");
    }

    // Update is called once per frame
    void Update()
    {
        
    }
}
