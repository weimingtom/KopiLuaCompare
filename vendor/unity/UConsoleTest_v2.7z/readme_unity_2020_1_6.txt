1. define: UNITY_5
2. add ConsoleGui to Camera
