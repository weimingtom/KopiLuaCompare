void lua_xxx()
{
	extern Table *_registry; //see init_registry
	Table *t = _registry; //_tt;
  {
	  int i;
  for (i = 1; i < 3; ++i)
  {
    TValue *temp = &t->array[i-1];
	if (ttisthread(temp)) //tt_ == 0x48 = 72; low 4bit: 8 is thread
	{
	printf("lua_xxx 003: thread at array[%d]\n", i-1);
	}
	if (ttistable(temp)) //tt_ == 0x45 = 69; low 4bit: 5 is table
	{
	printf("lua_xxx 004: table at array[%d]\n", i-1);
	}
  }
  }
}
