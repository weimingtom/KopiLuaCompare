
extern "C"
{
#include <lua/include/lua.h>
#include <lua/include/lualib.h>
#include <lua/include/lauxlib.h>
};
#include <luabind/luabind.hpp>
#include <luabind/object.hpp>
#include <iostream>

int main(int argc, char* argv[])
{
	lua_State* L = lua_open();
	luabind::open(L);
	luaopen_base(L);
	luaopen_string(L);


	lua_dostring(L,"a=1");

	luabind::detail::proxy_object a=luabind::get_globals(L)["a"];
	
	a=2;

	lua_dostring(L,"print(tostring(a));");

	lua_close(L);
	

	return 0;
}