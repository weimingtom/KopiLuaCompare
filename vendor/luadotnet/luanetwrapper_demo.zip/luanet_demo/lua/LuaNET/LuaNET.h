#pragma once


extern "C"
{
#include <lua/include/lua.h>
#include <lua/include/lualib.h>
#include <lua/include/lauxlib.h>
};
#include <luabind/luabind.hpp>
#include <luabind/object.hpp>

extern "C"
{
	struct lua_State;
};

//<summary>
//Thin wrapper around Lua.
//</summary>
namespace Lua
{

	namespace Details
	{
		private __gc class StringPtr
		{
		public:
			explicit StringPtr( System::String __gc* string_);
			~StringPtr();
			const char* ToCSTR();
			System::String __gc* ToStringAuto();
		protected:
			System::IntPtr m_ptr;
		};
	};


	// A lua variable
	public __gc class LuaObject 
	{
	public:
		//<summary>Construct an object out of a luabind object.</summary>
		//<param name="object_>object to copy</param>
		//<remarks>This constructors should not be called directly.</remarks>
		LuaObject( luabind::object const& object_);
		~LuaObject();

		//<summary>returns true if is of double type</summary>
		//<value>returns true if is of double type</value>
		__property System::Boolean get_IsDouble();
		//<summary>returns true if is of string type</summary>
		//<value>returns true if is of string type</value>
		__property System::Boolean get_IsString();
		//<summary>returns true if is of boolean type</summary>
		//<value>returns true if is of boolean type</value>
		__property System::Boolean get_IsBoolean();
		//<summary>returns true if is of table type</summary>
		//<value>returns true if is of table type</value>
		__property System::Boolean get_IsTable();
		//<summary>returns true if the value has no type</summary>
		//<value>returns true if the value has no type</value>
		__property System::Boolean get_IsNil();

		//<summary>
		//Sets the object value as <see cref="o_"/>
		//</summary>
		//<param name="o_">value to set</param>
		//<exception cref="ArgumentNullException">If <see cref="o_"> is null</exception>
		void Set( LuaObject __gc* o_);
		//<summary>
		//Sets the object value as <see cref="d_"/>
		//</summary>
		//<param name="d_">value to set</param>
		void Set( System::Double d_);
		//<summary>
		//Sets the object value as <see cref="i_"/>
		//</summary>
		//<param name="i_">value to set</param>
		void Set( System::Int32 i_);
		//<summary>
		//Sets the object value as <see cref="s_"/>
		//</summary>
		//<param name="s_">value to set</param>
		//<exception cref="ArgumentNullException">If <see cref="s_"/> is null</exception>
		void Set( System::String __gc* s_);
		//<summary>
		//Sets the object value as <see cref="o_"/>
		//</summary>
		//<param name="o_">value to set</param>
		void Set( System::Boolean b_);

		//<summary>
		//Converts to <seealso cref="Double"/>.
		//<summary>
		//<returns>the double value contained in the lua object</returns>
		//<exception cref="Exception">If object is not of type double</exception>
		System::Double ToDouble();
		//<summary>
		//Converts to <seealso cref="String"/>.
		//<summary>
		//<returns>converts any double, boolean or string value contained in the lua object</returns>
		//<exception cref="Exception">If object is not of type boolean, double or string</exception>
		System::String __gc* ToString();
		//<summary>
		//Converts to <seealso cref="Boolean"/>.
		//<summary>
		//<returns>the boolean value contained in the lua object</returns>
		//<exception cref="Exception">If object is not of type boolean</exception>
		System::Boolean ToBoolean();
		
		//<value>return false</value>
		__property System::Boolean get_IsFixedSize();
		//<value>return false</value>
		__property System::Boolean get_IsReadOnly();

		//<summary>returns the item identified by the key</summary>
		//<value>returns the item identified by the key</value>
		//<param name="key_">key identifier</param>
		//<returns>a LuaObject</returns>
		//<exception cref="ArgumentNullException">key_ is null</exception>
		//<exception cref="ArgumentException">key_ was not found</exception>
		__property System::Object __gc* get_Item( System::Object __gc* key_);
		//<summary>modifies the item identified by key</summary>
		//<value>modifies the item identified by key</value>
		//<param name="key_">key identifier</param>
		//<param name="value_">value to add</param>
		//<returns>a LuaObject</returns>
		//<exception cref="ArgumentNullException">key_ is null</exception>
		//<exception cref="ArgumentNullException">value_ is null</exception>
		//<exception cref="ArgumentException">key_ was not found</exception>
		__property void set_Item( System::Object __gc* key_, System::Object __gc* value_);				

		//<summary>returns a collection containing all keys</summary>
		//<value>returns a collection containing all keys</value>
		__property System::Collections::ICollection __gc* get_Keys();
		//<summary>returns a collection containing all values</summary>
		//<value>returns a collection containing all values</value>
		__property System::Collections::ICollection __gc* get_Values();

//		__property System::Int32 get_Count();
		//<value>returns false</value>
		__property System::Boolean get_IsSynchronized();
		//<value>returns self pointer</value>
		__property System::Object __gc* get_SyncRoot();
		//<summary>copies values to an array</summary>
		//<param name="array">array to fill</param>
		//<param name="index">index to start copying</param>
		//<exception cref="ArgumentNullException">array is null</exception>
		//<exception cref="ArgumentException">index is negative</exception>
		//<exception cref="ArgumentException">array dimension is too small</exception>
		void CopyTo( System::Array __gc* array, int index);

		//<summary>Adds a key-value pair</summar>
		//<param name="key_">key identifier</param>
		//<param name="value_">value to add</param>
		//<exception cref="ArgumentNullException">key_ is null</exception>
		//<exception cref="ArgumentNullException">value_ is null</exception>
		//<exception cref="ArgumentException">key_ is already defined</exception>
		void Add(System::Object __gc* key_, System::Object __gc* value_);

		//<summary>Not working yet</summary>
		void Clear();
		//<summary>return true if key is in the table</summary>
		//<param name="key_">key to look for</param>
		//<returns>true if found, false otherwize</returns>
		//<exceptions cref="ArgumentNullException">key_ is null</exception>
		System::Boolean Contains( System::Object __gc* key_);

		//<summary>returns an enumerator over the key-values pair</summary>
		System::Collections::IDictionaryEnumerator __gc* GetEnumerator();
		//<summary>Not working yet</summary>
		void Remove( System::Object __gc* key_ );

		luabind::object* get_object() {	return m_object;};
	private:
		luabind::object* m_object;
	};
	
	//<summary>A lua table enumerator</summary>
	public __gc class TableEnumerator
	:
		public System::Collections::IDictionaryEnumerator
	{
	public:
		TableEnumerator(luabind::object const& object_);
		~TableEnumerator();

		__property System::Object __gc* get_Current();
		//<summary>resets the iterator position</summary>
		void Reset();
		//<summary>moves the iterator to the next item
		//<returns>true if the item is valid, false if the end of the enumeration has been reached</returns>
		System::Boolean MoveNext();

		//<value>returns the current key-value pair</value>
		__property System::Collections::DictionaryEntry get_Entry();
		//<value>return the current key</value>
		__property System::Object __gc* get_Key();
		//<value>return the current value</value>
		__property System::Object __gc* get_Value();

	protected:
		luabind::object* m_object;
		luabind::object::iterator* m_iterator;
	};

	//<summary>A Lua State</summary>
	public __gc class State 
	{
	public:
		//<summary>Opens a lua state</summary>
		State();
		//<summary>Releases lua state
		~State();

		//<summary>returns the lua state structure</summary>
		//<remarks>This method should be used in Managed C++ only</remarks>
		lua_State* L();

		//<summary>Executes lua code in a string</summary>
		//<param name="code_">string containing lua code to execute</param>
		void DoString( System::String __gc* code_ );	
		//<summary>Exectues lua code in a file </summary>
		//<param name="file_name_">string containing a file name of lua code to execute</param>
		void DoFile( System::String __gc* file_name_ );

		//<summary>get the table of global variables</summary>
		//<returns>lua global variable table </summary>
		LuaObject __gc* GetGlobals();
		//<summary>gets a global variable</summary>
		//<param name="name_">variable name</summary>
		//<returns>variable named name_</returns>
		//<exception cref="ArgumentNullException">name_ is null</exception>
		__property LuaObject __gc* get_Global( System::Object __gc* name_);
		//<summary>sets a global variable value</summary>
		//<param name="name_">variable name</summary>
		//<exception cref="ArgumentNullException">name_ is null</exception>
		//<exception cref="ArgumentNullException">value_ is null</exception>
		__property void set_Global( System::Object __gc* name_, LuaObject __gc* value_);
	private:
		lua_State* m_L;
	};

	// Lua state creation engine
	public __gc class Engine
	{
	public:
		//<summary>Default constructor</summary>
		//<remarks>Not useful now, kept for future use</remarks>
		Engine();

		//<summary>Creates a new Lua state</summary>
		//<return>lua state</return>
		State __gc* CreateState();
	};

	namespace Libraries
	{
	//<summary>Lua Default library loaders</summary>
	public  __value struct DefaultLibrary
	{
		//<summary>Loads all default library in the lua state</summary>
		//<param name="s_">state where to load the libs</summary>
		//<expection cref="ArgumentNullException">s_ is null</exception>
		static void Load( State __gc* s_);
		//<summary>Loads base library in the lua state</summary>
		//<param name="s_">state where to load the libs</summary>
		//<expection cref="ArgumentNullException">s_ is null</exception>
		static void LoadBase( State __gc* s_);
		//<summary>Loads table library in the lua state</summary>
		//<param name="s_">state where to load the libs</summary>
		//<expection cref="ArgumentNullException">s_ is null</exception>
		static void LoadTable( State __gc* s_);
		//<summary>Loads io library in the lua state</summary>
		//<param name="s_">state where to load the libs</summary>
		//<expection cref="ArgumentNullException">s_ is null</exception>
		static void LoadIO( State __gc* s_);
		//<summary>Loads string library in the lua state</summary>
		//<param name="s_">state where to load the libs</summary>
		//<expection cref="ArgumentNullException">s_ is null</exception>
		static void LoadString( State __gc* s_);
		//<summary>Loads math library in the lua state</summary>
		//<param name="s_">state where to load the libs</summary>
		//<expection cref="ArgumentNullException">s_ is null</exception>
		static void LoadMath( State __gc* s_);
		//<summary>Loads  loadlib library in the lua state</summary>
		//<param name="s_">state where to load the libs</summary>
		//<expection cref="ArgumentNullException">s_ is null</exception>
		static void LoadLoadlib( State __gc* s_);
	};

	//<summary>Luabind library loaders</summary>
	public __value  struct LuabindLibrary
	{
		//<summary>Loads  luabind library in the lua state</summary>
		//<param name="s_">state where to load the libs</summary>
		//<expection cref="ArgumentNullException">s_ is null</exception>
		static void Load( State __gc * s_);
	};
	};
};
