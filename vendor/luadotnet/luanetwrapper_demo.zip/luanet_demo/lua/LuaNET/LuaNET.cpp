// Il s'agit du fichier DLL principal.

#include "stdafx.h"

#include "LuaNET.h"



extern "C"
{
	struct lua_State {};
};

namespace Lua
{
	namespace Details
	{
		StringPtr::StringPtr( System::String __gc* string_)
		{
			if (string_ == NULL)
				throw new System::ArgumentNullException(S"string");

			m_ptr = System::Runtime::InteropServices::Marshal::StringToHGlobalAnsi( string_);
		}

		StringPtr::~StringPtr()
		{
			System::Runtime::InteropServices::Marshal::FreeHGlobal( m_ptr );
		};
		const char* StringPtr::ToCSTR()
		{
			return static_cast<const char*>(m_ptr.ToPointer());
		}
		System::String __gc* StringPtr::ToStringAuto()
		{
			return System::Runtime::InteropServices::Marshal::PtrToStringAuto(m_ptr);
		}
	};

	Engine::Engine()
	{
	};

	State __gc* Engine::CreateState()
	{
		State __gc* state_ = new State();

		return state_;
	};

	TableEnumerator::TableEnumerator( luabind::object const& object_)
	: 
		m_object( new luabind::object( object_ ) ),
		m_iterator(NULL)
	{
		if (m_object->type() != LUA_TTABLE)
			throw new System::ArgumentException("object_", "object is not a lua table");
	};

	TableEnumerator::~TableEnumerator()
	{
		Reset();
		delete m_object;
	}

	System::Object* TableEnumerator::get_Current()
	{
		if (
			   m_iterator == NULL 
			|| !( m_iterator->operator != (m_object->end()) )
			)
			throw new System::InvalidOperationException();

		return new LuaObject( **m_iterator );
	}

	void TableEnumerator::Reset()
	{
		if (m_iterator)
			delete m_iterator;
		m_iterator = NULL;
	}
	System::Boolean TableEnumerator::MoveNext()
	{
		if (m_iterator == NULL)
			m_iterator = new luabind::object::iterator( m_object->begin() );
		else
		{
			if ( !(m_iterator->operator !=( m_object->end()) ) )
				return false;

			m_iterator->operator ++();
		}
		return m_iterator->operator !=(m_object->end());
	}

	System::Collections::DictionaryEntry TableEnumerator::get_Entry()
	{
		if (
			   m_iterator == NULL 
			|| !( m_iterator->operator != (m_object->end()) )
			)
			throw new System::InvalidOperationException();

		return System::Collections::DictionaryEntry(get_Key(),get_Value());
	}

	System::Object __gc* TableEnumerator::get_Key()
	{
		if (
			   m_iterator == NULL 
			|| !( m_iterator->operator != (m_object->end()) )
			)
			throw new System::InvalidOperationException();

		return new LuaObject(m_iterator->key());
	}
	System::Object __gc* TableEnumerator::get_Value()
	{
		if (
			   m_iterator == NULL 
			|| !( m_iterator->operator != (m_object->end()) )
			)
			throw new System::InvalidOperationException();

		return new LuaObject(**m_iterator);
	};

	State::State()
	{
		m_L = lua_open();
	};
	State::~State()
	{
		lua_close(m_L); 
		m_L=NULL;
	}

	lua_State* State::L()
	{
		return m_L;
	}

	void State::DoString( System::String __gc* code_ )
	{
		if (code_ == NULL)
			throw new System::ArgumentNullException(S"lua code");

		Details::StringPtr __gc* code_str=new Details::StringPtr( code_ );
		lua_dostring( m_L, code_str->ToCSTR() );
	};

	void State::DoFile( System::String __gc* file_name_ )
	{
		if (file_name_ == NULL)
			throw new System::ArgumentNullException(S"file_name_");

		Details::StringPtr __gc* file_name=new Details::StringPtr( file_name_ );
		lua_dostring( m_L, file_name->ToCSTR() );
	}

	LuaObject __gc* State::GetGlobals()
	{
		return new LuaObject( luabind::get_globals( m_L) );
	};	
	
	LuaObject::LuaObject( luabind::object const& object_)
	: m_object( new luabind::object(object_))
	{};

	LuaObject::~LuaObject()
	{
		delete m_object;
	}

	void LuaObject::Set( System::Double d_)
	{
		m_object->operator =(d_);
	};

	void LuaObject::Set( System::Int32 i_)
	{
		m_object->operator =(i_);
	};
	void LuaObject::Set( System::String __gc* s_)
	{
		if (s_ == NULL)
			throw new System::ArgumentNullException(S"string");

		Details::StringPtr __gc* str = new Details::StringPtr(s_);
		m_object->operator =( str->ToCSTR() );
	}
	void LuaObject::Set( System::Boolean b_)
	{
		m_object->operator =(b_);
	};

	void LuaObject::Set( LuaObject __gc* o_)
	{
		m_object->operator =(*(o_->m_object));
	}


	System::Boolean LuaObject::get_IsDouble()
	{
		return m_object->is_valid() && m_object->type() == LUA_TNUMBER;
	}
	System::Boolean LuaObject::get_IsString()
	{
		return m_object->is_valid() && m_object->type() == LUA_TSTRING;
	}
	System::Boolean LuaObject::get_IsBoolean()
	{
		return m_object->is_valid() && m_object->type() == LUA_TBOOLEAN;
	}
	System::Boolean LuaObject::get_IsTable()
	{
		return m_object->is_valid() && m_object->type() == LUA_TTABLE;
	}
	System::Boolean LuaObject::get_IsNil()
	{
		return m_object->is_valid() && m_object->type() == LUA_TNIL;
	}

	System::Double LuaObject::ToDouble()
	{
		if (!m_object->is_valid())
			throw new System::Exception("object is not valid");
		if (m_object->type() != LUA_TNUMBER)
			throw new System::Exception(S"object is not a number");

		return System::Double( luabind::object_cast<double>(*m_object) );
	}

	System::String __gc* LuaObject::ToString()
	{
		if (!m_object->is_valid())
			throw new System::Exception("object is not valid");

		switch( m_object->type())
		{
		case LUA_TBOOLEAN:
			return System::Convert::ToString(luabind::object_cast<bool>(*m_object));
		case LUA_TNUMBER:
			return System::Convert::ToString( luabind::object_cast<double>(*m_object) );
		case LUA_TSTRING:
			return new System::String( luabind::object_cast<const char*>(*m_object) );
		default:
			throw new System::Exception(S"could not be converted to string");
		};
	}

	System::Boolean LuaObject::ToBoolean()
	{
		if (!m_object->is_valid())
			throw new System::Exception("object is not valid");

		if (m_object->type() != LUA_TBOOLEAN)
			throw new System::Exception(S"object is not a number");

		return System::Boolean( luabind::object_cast<bool>(*m_object) );
	}

	System::Boolean LuaObject::get_IsFixedSize()
	{
		if (!m_object->is_valid())
			throw new System::Exception("object is not valid");

		if (m_object->type() != LUA_TTABLE)
			throw new System::Exception(S"lua object is not a table, does not support table methods");

		return false;
	};
	System::Boolean LuaObject::get_IsReadOnly()
	{
		if (!m_object->is_valid())
			throw new System::Exception("object is not valid");

		if (m_object->type() != LUA_TTABLE)
			throw new System::Exception(S"object is not a table");

		return false;
	};


	System::Object __gc* LuaObject::get_Item( System::Object __gc* key_)
	{
		if (!m_object->is_valid())
			throw new System::Exception("object is not valid");

		if (m_object->type() != LUA_TTABLE)
			throw new System::Exception(S"object is not a table");

		if (key_ == NULL)
			throw new System::ArgumentNullException(S"key");

		Details::StringPtr __gc* key = new Details::StringPtr( key_->ToString() );
		return new LuaObject(
			m_object->at( key->ToCSTR() )
			);
	}
	void LuaObject::set_Item( System::Object __gc* key_, System::Object __gc* value_)
	{
		if (!m_object->is_valid())
			throw new System::Exception("object is not valid");

		if (m_object->type() != LUA_TTABLE)
			throw new System::Exception(S"object is not a table");

		if (key_ == NULL)
			throw new System::ArgumentNullException(S"key");

		Details::StringPtr __gc* key = new Details::StringPtr( key_->ToString() );
		Details::StringPtr __gc* value = new Details::StringPtr( value_->ToString() );
		m_object->at(  key->ToCSTR() ) = value->ToCSTR();
	}

	System::Collections::ICollection __gc* LuaObject::get_Keys()
	{
		if (!m_object->is_valid())
			throw new System::Exception("object is not valid");

		if (m_object->type() != LUA_TTABLE)
			throw new System::Exception(S"object is not a table");

		System::Collections::ArrayList __gc* list = new System::Collections::ArrayList();

		luabind::object::iterator it, it_end = m_object->end();
		for (
			it = m_object->begin();
			it != it_end;
			++it
			)
		{
			list->Add( new LuaObject( it.key() ) );
		};

		return list;
	};

	System::Collections::ICollection __gc* LuaObject::get_Values()
	{
		if (!m_object->is_valid())
			throw new System::Exception("object is not valid");

		if (m_object->type() != LUA_TTABLE)
			throw new System::Exception(S"object is not a table");

		System::Collections::ArrayList __gc* list = new System::Collections::ArrayList();

		luabind::object::iterator it, it_end = m_object->end();
		for (
			it = m_object->begin();
			it != it_end;
			++it
			)
		{
			list->Add( new LuaObject( *it ) );
		};

		return list;
	};

	void LuaObject::Add(System::Object __gc* key_, System::Object __gc* value_)
	{
		if (!m_object->is_valid())
			throw new System::Exception("object is not valid");

		if (m_object->type() != LUA_TTABLE)
			throw new System::Exception(S"object is not a table");

		if (key_ == NULL)
			throw new System::ArgumentNullException(S"key");

		if (value_ == NULL)
			throw new System::ArgumentNullException(S"value");

		if ( Contains( key_) )
			throw new System::ArgumentException(S"key_",S"key already in lua");

		Details::StringPtr __gc* key = new Details::StringPtr( key_->ToString() );
		Details::StringPtr __gc* value = new Details::StringPtr( value_->ToString() );
		m_object->at( key->ToCSTR() )
			= value->ToCSTR();
	}

	void LuaObject::Clear()
	{
		if (!m_object->is_valid())
			throw new System::Exception("object is not valid");

		if (m_object->type() != LUA_TTABLE)
		{
				lua_pushnil(m_object->lua_state());
				m_object->set();
		}
		else
		{
			luabind::object::iterator it, it_end = m_object->end();
			for (
				it = m_object->begin();
				it != it_end;
				++it)
			{
				lua_pushnil(m_object->lua_state());
				(*it).set();
			}
		}
	}

	System::Boolean LuaObject::Contains( System::Object __gc* key_)
	{
		if (!m_object->is_valid())
			throw new System::Exception("object is not valid");

		if (m_object->type() != LUA_TTABLE)
			throw new System::Exception("object is not a table");

		if (key_ == NULL)
			throw new System::ArgumentNullException(S"key");

		Details::StringPtr __gc* str = new Details::StringPtr( key_->ToString() );
		luabind::object o=m_object->at( str->ToCSTR() );
		return o && o.type() != LUA_TNIL;
	}

	void LuaObject::Remove( System::Object __gc* key_ )
	{
		if (!m_object->is_valid())
			throw new System::Exception("object is not valid");

		if (m_object->type() != LUA_TTABLE)
			throw new System::Exception("object is not a table");

		if (key_ == NULL)
			throw new System::ArgumentNullException(S"key_");

		if ( Contains( key_) )
		{
			lua_pushnil(m_object->lua_state());
			Details::StringPtr __gc* str = new Details::StringPtr( key_->ToString() );
			m_object->at( str->ToCSTR() ).set();
		}
	}

	System::Collections::IDictionaryEnumerator __gc* LuaObject::GetEnumerator()
	{
		if (!m_object->is_valid())
			throw new System::Exception("object is not valid");

		return new TableEnumerator( *m_object );
	}

	System::Boolean LuaObject::get_IsSynchronized()
	{
		if (!m_object->is_valid())
			throw new System::Exception("object is not valid");

		return false;
	};

	System::Object __gc* LuaObject::get_SyncRoot()
	{
		if (!m_object->is_valid())
			throw new System::Exception("object is not valid");

		return this;
	};

	LuaObject __gc* State::get_Global( System::Object __gc* name_)
	{
		if (name_ == NULL)
			throw new System::ArgumentNullException(S"name");

		Details::StringPtr __gc* str = new Details::StringPtr( name_->ToString() );
		return new LuaObject(luabind::get_globals(m_L)[ str->ToCSTR() ]);
	}
		
	void LuaObject::CopyTo( System::Array __gc* array, int index)
	{
		if (!m_object->is_valid())
			throw new System::Exception("object is not valid");

		if (array == NULL)
			throw new System::ArgumentNullException(S"array");
		if (index < 0)
			throw new System::ArgumentException(S"index is negative");


		luabind::object::iterator it, it_end = m_object->end();
		int i, i_end = array->get_Length();
		for (
			it = m_object->begin(),
			i = index;
			it != it_end
			&& i != i_end;
			++it, ++i
				)
		{
			array->set_Item( i, new LuaObject( *it ) );
		}

		if ( it != it_end )
			throw new System::ArgumentException("array is too small");
	}

	void State::set_Global( System::Object __gc* name_, LuaObject __gc* value_)
	{
		if (name_ == NULL)
			throw new System::ArgumentNullException(S"name");
		if (value_ == NULL)
			throw new System::ArgumentNullException(S"value");

		Details::StringPtr __gc* str = new Details::StringPtr( name_->ToString() );

		luabind::get_globals(m_L)[ str->ToCSTR() ] = *(value_->get_object());
	}

	void Libraries::DefaultLibrary::Load( State __gc* s_)
	{
		if (s_ == NULL)
			throw new System::ArgumentNullException(S"state");

		LoadBase(s_);
		LoadTable(s_);
		LoadIO(s_);
		LoadString(s_);
		LoadMath(s_);
		LoadLoadlib(s_);
	};

	void Libraries::DefaultLibrary::LoadBase( State __gc* s_)
	{
		if (s_ == NULL)
			throw new System::ArgumentNullException(S"state");

		luaopen_base( s_->L() );
	}
	void Libraries::DefaultLibrary::LoadTable( State __gc* s_)
	{
		if (s_ == NULL)
			throw new System::ArgumentNullException(S"state");

		luaopen_table( s_->L() );
	}
	void Libraries::DefaultLibrary::LoadIO( State __gc* s_)
	{
		if (s_ == NULL)
			throw new System::ArgumentNullException(S"state");

		luaopen_io( s_->L() );
	}
	void Libraries::DefaultLibrary::LoadString( State __gc* s_)
	{
		if (s_ == NULL)
			throw new System::ArgumentNullException(S"state");

		luaopen_string( s_->L() );
	}
	void Libraries::DefaultLibrary::LoadMath( State __gc* s_)
	{
		if (s_ == NULL)
			throw new System::ArgumentNullException(S"state");

		luaopen_math( s_->L() );
	}

	void Libraries::DefaultLibrary::LoadLoadlib( State __gc* s_)
	{
		if (s_ == NULL)
			throw new System::ArgumentNullException(S"state");

		luaopen_loadlib( s_->L() );
	}
	
	void Libraries::LuabindLibrary::Load( State __gc * s_)
	{
		if (s_ == NULL)
			throw new System::ArgumentNullException(S"state");

		luabind::open( s_->L() );
	}

};