========================================================================
    BIBLIOTH�QUES DE LIAISONS DYNAMIQUES : vue d'ensemble du projet LuaNET
========================================================================

AppWizard a cr�� cette DLL LuaNET pour vous.  

Ce fichier contient un r�sum� du contenu de chacun des fichiers qui
constituent votre application LuaNET.

LuaNET.vcproj
    Il s'agit du fichier projet principal pour les projets VC++ g�n�r�s � l'aide d'un Assistant Application. 
    Il contient les informations sur la version de Visual C++ qui a g�n�r� le fichier et 
    des informations sur les plates-formes, configurations et fonctionnalit�s du projet s�lectionn�es avec
    l'Assistant Application.

LuaNET.cpp
    Il s'agit du fichier source principal de la DLL.

LuaNET.h
    Ce fichier contient une d�claration de classe.

AssemblyInfo.cpp
	Contient des attributs personnalis�s pour modifier les m�tadonn�es de l'assembly.

/////////////////////////////////////////////////////////////////////////////
Autres remarques�:

AppWizard utilise "TODO�:" pour indiquer les parties du code source que vous
devez ajouter ou personnaliser.

/////////////////////////////////////////////////////////////////////////////
