========================================================================
    BIBLIOTH�QUES DE LIAISONS DYNAMIQUES : vue d'ensemble du projet Luapp
========================================================================

AppWizard a cr�� cette DLL Luapp pour vous.  
Ce fichier contient un r�sum� du contenu de chacun des fichiers qui
constituent votre application Luapp.


Luapp.vcproj
    Il s'agit du fichier projet principal pour les projets VC++ g�n�r�s en utilisant un Assistant Application. 
    Il contient les informations sur la version de Visual C++ qui a g�n�r� le fichier et 
    les informations sur les plates-formes, les configurations et les fonctionnalit�s du projet s�lectionn�es avec
    l'Assistant Application.

Luapp.cpp
    Il s'agit du fichier source DLL principal.

	Une fois cr��e, cette DLL n'exporte aucun symbole. Il en r�sulte qu'elle  
	ne produira pas un fichier .lib lors de la g�n�ration. Si vous souhaitez que ce projet 
	soit une d�pendance d'un autre projet, vous devez 
	ajouter du code pour exporter des symboles � partir de la DLL afin qu'une biblioth�que d'exportation 
	soit cr��e ou vous pouvez d�finir la propri�t� Ignore Input Library � la valeur Yes 
	dans la page de propri�t�s G�n�ral du dossier �diteur de liens de la bo�te de dialogue Pages de propri�t�s 
	du projet.

/////////////////////////////////////////////////////////////////////////////
Autres fichiers standard�:

StdAfx.h, StdAfx.cpp
    Ces fichiers sont utilis�s pour g�n�rer un fichier d'en-t�te pr�compil� (PCH) 
    nomm� Luapp.pch et un fichier de type pr�compil� nomm� StdAfx.obj.

/////////////////////////////////////////////////////////////////////////////
Autres remarques�:

AppWizard utilise des commentaires "TODO�:" pour indiquer les parties du code source o� vous
pouvez ajouter ou modifier du code.

/////////////////////////////////////////////////////////////////////////////
