// Luapp.cpp : d�finit le point d'entr�e pour l'application DLL.
//

#include "stdafx.h"
#include <vector>
#include <boost/utility.hpp>
extern "C"
{
	#include <lua/include/lua.h>
	#include <lua/include/lualib.h>
	#include <lua/include/lauxlib.h>
};

#ifndef LUAPP_DLL
	#define LUAPP_API __declspec(dllexport)
#else
	#define LUAPP_API __declspec(dllexport)
#endif

BOOL APIENTRY DllMain( HANDLE hModule, 
                       DWORD  ul_reason_for_call, 
                       LPVOID lpReserved
					 )
{
    return TRUE;
}

namespace lua
{
	class LUAPP_API lua_sate :
		public boost::noncopyable
	{
	public:
		explicit lua_state()
		{
			m_L = lua_open();
		};
		~lua_state()
		{
			lua_close(m_L);
			m_L=NULL;
		};
	private:
		lua_State* m_L;
	};
};