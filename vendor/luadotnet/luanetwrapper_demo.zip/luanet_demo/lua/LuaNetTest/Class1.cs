using System;
using Lua;

namespace LuaNetTest
{
	/// <summary>
	/// Description r�sum�e de Class1.
	/// </summary>
	class Class1
	{
		/// <summary>
		/// Point d'entr�e principal de l'application.
		/// </summary>
		[STAThread]
		static void Main(string[] args)
		{
			Lua.Engine engine=new Engine();

			Lua.State state = engine.CreateState();
			Lua.Libraries.DefaultLibrary.Load(state);
			Lua.Libraries.LuabindLibrary.Load(state);

			state.DoString("a=1;");
			state.DoString("s='string';");
			state.DoString("t={1,'string'};");
			state.DoString("print('a: ' .. tostring(a));");
			state.DoString("print('s: ' .. tostring(s));");

			LuaObject a=state.get_Global("a");
			LuaObject s=state.get_Global("s");
			LuaObject t=state.get_Global("t");

			System.Console.WriteLine( "a:" + a.ToDouble() );
			System.Console.WriteLine( "s: " + s.ToString() );
			System.Collections.IDictionaryEnumerator te = t.GetEnumerator();
			while( te.MoveNext() )
			{
				System.Console.WriteLine("t...(" + te.Key + "," + te.Value +")");
			}

			a.Set(s);
			s.Set(t);

			state.set_Global("a", a);
			state.set_Global("s", s);
			state.DoString("print('a: ' .. tostring(a));");
			state.DoString("print('s: ' .. tostring(s));");
		}
	}
}
