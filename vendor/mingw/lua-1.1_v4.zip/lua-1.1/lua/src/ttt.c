#include <stdio.h>

/*
b _filbuf
*/
void testxxx()
{
	int i = getc(stdin);
}